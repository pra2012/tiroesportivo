import os
import sys
import logging
from pathlib import Path

# Configurar logging para Azure
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Configurar paths
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

from flask import Flask, send_from_directory, jsonify, request
from flask_cors import CORS
from src.models.user import db
from src.models.shooting import Weapon, Competition, CompetitionScore, Level, TrainingSession, UserProgress
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.weapons import weapons_bp
from src.routes.competitions import competitions_bp
from src.routes.levels import levels_bp
from src.routes.training import training_bp

# Criar aplicação Flask
app = Flask(__name__, static_folder=str(current_dir / 'static'))

# Configurações para Azure
app.config.update({
    'SECRET_KEY': os.environ.get('SECRET_KEY', 'shooting-sports-azure-secret-key-2024'),
    'SQLALCHEMY_DATABASE_URI': f"sqlite:///{current_dir}/instance/database.db",
    'SQLALCHEMY_TRACK_MODIFICATIONS': False,
    'FLASK_ENV': 'production',
    'DEBUG': False,
    'TESTING': False,
    'PREFERRED_URL_SCHEME': 'https'
})

# Configurar CORS para Azure
CORS(app, 
     origins=['*'],
     allow_headers=['Content-Type', 'Authorization'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])

# Middleware para logging de requests
@app.before_request
def log_request_info():
    logger.info(f"Request: {request.method} {request.url}")

@app.after_request
def log_response_info(response):
    logger.info(f"Response: {response.status_code}")
    return response

# Registrar blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(weapons_bp, url_prefix='/api')
app.register_blueprint(competitions_bp, url_prefix='/api')
app.register_blueprint(levels_bp, url_prefix='/api')
app.register_blueprint(training_bp, url_prefix='/api')

# Inicializar banco de dados
db.init_app(app)

# Health check para Azure
@app.route('/api/health')
def health_check():
    """Endpoint de verificação de saúde da aplicação"""
    try:
        # Testar conexão com banco
        with app.app_context():
            db.session.execute('SELECT 1')
        
        return jsonify({
            'status': 'healthy',
            'message': 'Shooting Sports API is running on Azure',
            'version': '1.0.0',
            'environment': 'production'
        }), 200
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return jsonify({
            'status': 'unhealthy',
            'message': str(e)
        }), 500

# Rota para servir arquivos estáticos do frontend
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    """Servir arquivos estáticos do frontend React"""
    static_folder_path = app.static_folder
    
    if static_folder_path is None:
        logger.error("Static folder not configured")
        return "Static folder not configured", 404

    # Se é um arquivo específico e existe, servir
    if path and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    
    # Para rotas SPA, sempre servir index.html
    index_path = os.path.join(static_folder_path, 'index.html')
    if os.path.exists(index_path):
        return send_from_directory(static_folder_path, 'index.html')
    else:
        logger.error("index.html not found")
        return "Frontend not found", 404

# Handler de erro global
@app.errorhandler(Exception)
def handle_exception(e):
    logger.error(f"Unhandled exception: {e}")
    return jsonify({
        'error': 'Internal server error',
        'message': 'An unexpected error occurred'
    }), 500

# Inicialização para Azure
def create_app():
    """Factory function para criar a aplicação"""
    
    # Criar diretório instance se não existir
    instance_dir = current_dir / 'instance'
    instance_dir.mkdir(exist_ok=True)
    
    with app.app_context():
        try:
            db.create_all()
            logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Error creating database tables: {e}")
    
    return app

if __name__ == '__main__':
    # Para desenvolvimento local
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
else:
    # Para Azure Web App
    application = create_app()
    logger.info("Application created for Azure Web App")

